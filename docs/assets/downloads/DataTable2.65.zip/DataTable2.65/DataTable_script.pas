program DataTable;
var 
    NSign : TNumber_Sign;
    NAlt : TNumber_Alt;
begin
//------------------------------------------------------------------------------
  NSign := AddSign(qJ,10);
  SetSignLabel(NSign, 'Новый мультивариантный признак');
  for NAlt := 1 to 10 do begin
    SetAltLabel(NSign,NAlt ,'Альтернатива №' + IntToStr(NAlt));
  end;
  
  writelog(IntToStr(CountOfAnks));

//------------------------------------------------------------------------------

//Поанкетная обработка
//------------------------------------------------------------------------------
for jjAnk := 1 to CountOfAnks do begin

   if GetN(3)=1                           then put(NSign,1);
   if (GetN(3)=3) or (GetN(3)=3)          then put(NSign,2);
   if (1 <= GetM(1)) and (GetM(1) <= 500) then put(NSign,3);
   if (GetJ(50,1) or GetJ(50,2))          then put(NSign,4);

   writelog(FloatToStr(GetM(93)));
   
end;
